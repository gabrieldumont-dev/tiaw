// Fluxo de telas
document.addEventListener('DOMContentLoaded', function () {
  const loginForm = document.getElementById('loginForm');
  const cadastroForm = document.getElementById('cadastroForm');

  // Login
  if (loginForm) {
    loginForm.addEventListener('submit', function (e) {
      e.preventDefault();

      const email = document.getElementById('usuarioLogin').value;
      const senha = document.getElementById('senhaLogin').value;

      const usuarioSalvo = JSON.parse(localStorage.getItem('usuario'));
      if (usuarioSalvo && usuarioSalvo.email === email && usuarioSalvo.senha === senha) {
        window.location.href = 'objetivo.html';
      } else {
        alert('Email ou senha inválidos');
      }
    });
  }

  // Cadastro
  if (cadastroForm) {
    cadastroForm.addEventListener('submit', function (e) {
      e.preventDefault();

      const email = document.getElementById('usuarioCadastro').value;
      const senha = document.getElementById('senhaCadastro').value;

      const usuario = { email, senha };
      localStorage.setItem('usuario', JSON.stringify(usuario));

      alert('Cadastro realizado com sucesso!');
      window.location.href = 'objetivo.html';
    });
  }
});


// Tela Objetivo

let sexoObjetivo = null;

const btnMulher = document.getElementById('mulherInput');
const btnHomem = document.getElementById('homemInput');

btnHomem.addEventListener('click', () => {
    sexoObjetivo = 'homem';
    btnHomem.classList.add('btnSelecionadoObjetivo');
    btnMulher.classList.remove('btnSelecionadoObjetivo');
});

btnMulher.addEventListener('click', () => {
    sexoObjetivo = 'mulher';
    btnMulher.classList.add('btnSelecionadoObjetivo');
    btnHomem.classList.remove('btnSelecionadoObjetivo');
});

let objetivo = null;

document.querySelectorAll('.btnObjetivoSelct').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.btnObjetivoSelct').forEach(b => b.classList.remove('ativo'));
        btn.classList.add('ativo');
        objetivo = btn.value.toLowerCase();
    });
});

document.querySelector('.formObjetivo form').addEventListener('submit', function (event) {
    event.preventDefault();

    const peso = parseFloat(document.getElementById('pesoInput').value.replace(',', '.'));
    const idade = parseInt(document.querySelector('.inputIdadeObjetivo input').value);
    const altura = parseInt(document.querySelector('.inputAlturaObjetivo input').value);
    const atividadeTrabalho = parseInt(document.getElementById('atvFisicaObjetivo').value);
    const exercicioSemanal = parseInt(document.getElementById('exercicioFisicoObjetivo').value);

    if (!sexoObjetivo || !objetivo || isNaN(peso) || isNaN(idade) || isNaN(altura)) {
        alert("Por favor, preencha todos os campos corretamente.");
        return;
    }

    const geb = calcularGEB(sexoObjetivo, idade, peso);
    const fator = determinarFator(atividadeTrabalho, exercicioSemanal);
    let gastoTotal = geb * fator;

    if (objetivo === "emagrecer") {
        gastoTotal -= 500; // redução padrão
    } else if (objetivo === "engordar") {
        gastoTotal += 500; // aumento padrão
    }

    const container = document.getElementById('containerObjetivo');
    let resposta = document.querySelector('#respostaObjetivo');
    if (!resposta) {
        resposta = document.createElement('p');
        resposta.id = 'respostaObjetivo';
        resposta.className = 'resposta';
        container.appendChild(resposta);
    }
    resposta.innerHTML = `Para o seu objetivo de <strong>${objetivo}</strong>, sua ingestão ideal é de <strong>${gastoTotal.toFixed(2)} kcal</strong> por dia.`;
});

function calcularGEB(sexo, idade, peso) {
    if (sexo === 'mulher') {
        if (idade < 3) return (58.317 * peso) - 31.1;
        if (idade < 10) return (20.315 * peso) + 485.9;
        if (idade < 18) return (13.384 * peso) + 692.6;
        if (idade < 30) return (14.818 * peso) + 486.6;
        if (idade < 60) return (8.126 * peso) + 845.6;
        return (9.082 * peso) + 658.5;
    } else {
        if (idade < 3) return (59.512 * peso) - 30.4;
        if (idade < 10) return (22.706 * peso) + 504.3;
        if (idade < 18) return (17.686 * peso) + 658.2;
        if (idade < 30) return (15.057 * peso) + 692.2;
        if (idade < 60) return (11.472 * peso) + 873.1;
        return (11.711 * peso) + 587.7;
    }
}

function determinarFator(atividade, exercicio) {
    const trabalho = {
        1: 1.4,
        2: 1.6,
        3: 1.8,
        4: 2.0
    };

    const exercicioExtra = {
        1: 0.0,
        2: 0.1,
        3: 0.15,
        4: 0.2,
        5: 0.25,
        6: 0.3
    };

    return trabalho[atividade] + exercicioExtra[exercicio];
}
