if (document.getElementById('form-treino')) {
  document.getElementById('form-treino').addEventListener('submit', function(e) {
    e.preventDefault();

    const treino = {
      tipo: this.tipo.value,
      tempo: this.tempo.value,
      calorias: this.calorias.value,
      passos: this.passos.value,
      data: this.data.value
    };

    const treinos = JSON.parse(localStorage.getItem('treinos')) || [];
    treinos.push(treino);
    localStorage.setItem('treinos', JSON.stringify(treinos));

    window.location.href = 'index.html';
  });
}

// Carregar histórico
if (document.getElementById('historico-treinos')) {
  const treinos = JSON.parse(localStorage.getItem('treinos')) || [];
  const container = document.getElementById('historico-treinos');

  treinos.forEach((treino, index) => {
    const div = document.createElement('div');
    div.className = 'card';
    div.innerHTML = `
      <div class="boxTreinos">
        <div class="boximg">
          ${treino.tipo === 'Musculação' ? `<img src="./assets/img/musculacao.webp" alt="">` : `<img src="./assets/img/cardio.jpg" alt="">`}
        </div>
        <div class="boxConteudo">
          <h2>${treino.tipo}</h2>
          <p><strong>Data:</strong> ${treino.data}</p> 
          <p><strong>Tempo:</strong> ${treino.tempo} min</p>
          <p><strong>Calorias:</strong> ${treino.calorias} kal</p>
          <p><strong>Passos:</strong> ${treino.passos}</p>
          <button class="btn-deletar" data-index="${index}">🗑️ Excluir</button>
        </div>
      </div>
    `;
    container.appendChild(div);
  });

  // Evento de delete
  document.querySelectorAll('.btn-deletar').forEach(button => {
    button.addEventListener('click', function(e) {
      e.stopPropagation(); // impede o clique do card de abrir a outra página
      const index = this.getAttribute('data-index');
      const treinos = JSON.parse(localStorage.getItem('treinos')) || [];
      treinos.splice(index, 1); // remove o treino do array
      localStorage.setItem('treinos', JSON.stringify(treinos));
      location.reload(); // recarrega a página para atualizar a lista
    });
  });
}